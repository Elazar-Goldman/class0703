## CLASS

# Goal: create a personal liaberary 

- In the liabrary you will have many books

- Every book will have

    - title

    - Auther
     
    - langth

    - possibly img

- Make a class that will build the books

## next build your reading list

 - name  - String

- Books I didn't read yet - Array

- my current book - Object

- books that I Read - Array

- Make a class that builds the bookd lists [optional]

## Book logic manager

- Create a new book for a user

- finsh reading a book for a user 



